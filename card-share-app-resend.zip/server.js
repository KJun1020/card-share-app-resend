import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import Database from 'better-sqlite3';
import nodemailer from 'nodemailer';
import { Resend } from 'resend';
import crypto from 'crypto';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');

app.use(cors());
app.use(express.json({ limit: '20kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const db = new Database(path.join(__dirname, 'cards.db'));
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS cards (
    id TEXT PRIMARY KEY,
    sender TEXT NOT NULL,
    message TEXT NOT NULL,
    receiver TEXT,
    method TEXT NOT NULL,
    created_at TEXT NOT NULL,
    opened_at TEXT,
    answer TEXT,
    answered_at TEXT
  );
`);

function makeId() {
  return crypto.randomBytes(8).toString('hex');
}

function requireText(value, name, maxLength) {
  if (typeof value !== 'string' || !value.trim()) {
    throw new Error(`${name}을(를) 입력해주세요.`);
  }
  if (value.trim().length > maxLength) {
    throw new Error(`${name}이(가) 너무 깁니다.`);
  }
  return value.trim();
}

let transporter = null;
let resendClient = null;

function getResend() {
  if (resendClient) return resendClient;
  if (!process.env.RESEND_API_KEY) return null;
  resendClient = new Resend(process.env.RESEND_API_KEY);
  return resendClient;
}

function getTransporter() {
  if (transporter) return transporter;
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return null;

  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 465),
    secure: String(process.env.SMTP_SECURE || 'true') === 'true',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
  return transporter;
}

app.post('/api/cards', (req, res) => {
  try {
    const sender = requireText(req.body.sender, '보내는 사람', 30);
    const message = requireText(req.body.message, '메시지', 500);
    const method = requireText(req.body.method, '보내는 방법', 30);
    const receiver = typeof req.body.receiver === 'string' ? req.body.receiver.trim().slice(0, 160) : '';
    const id = makeId();
    const createdAt = new Date().toISOString();

    db.prepare(`
      INSERT INTO cards (id, sender, message, receiver, method, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(id, sender, message, receiver, method, createdAt);

    const url = `${BASE_URL}/card/${id}`;
    res.json({ ok: true, id, url, createdAt });
  } catch (error) {
    res.status(400).json({ ok: false, message: error.message });
  }
});

app.get('/api/cards/:id', (req, res) => {
  const card = db.prepare(`SELECT * FROM cards WHERE id = ?`).get(req.params.id);
  if (!card) return res.status(404).json({ ok: false, message: '카드를 찾을 수 없습니다.' });

  if (!card.opened_at) {
    db.prepare(`UPDATE cards SET opened_at = ? WHERE id = ?`).run(new Date().toISOString(), card.id);
  }

  const latest = db.prepare(`SELECT id, sender, message, receiver, method, created_at, opened_at, answer, answered_at FROM cards WHERE id = ?`).get(card.id);
  res.json({ ok: true, card: latest });
});

app.post('/api/cards/:id/answer', (req, res) => {
  const card = db.prepare(`SELECT id FROM cards WHERE id = ?`).get(req.params.id);
  if (!card) return res.status(404).json({ ok: false, message: '카드를 찾을 수 없습니다.' });

  const answer = requireText(req.body.answer || 'YES', '답변', 20);
  const answeredAt = new Date().toISOString();
  db.prepare(`UPDATE cards SET answer = ?, answered_at = ? WHERE id = ?`).run(answer, answeredAt, req.params.id);
  res.json({ ok: true, answer, answeredAt });
});

app.get('/api/cards/:id/status', (req, res) => {
  const card = db.prepare(`SELECT id, sender, receiver, method, created_at, opened_at, answer, answered_at FROM cards WHERE id = ?`).get(req.params.id);
  if (!card) return res.status(404).json({ ok: false, message: '카드를 찾을 수 없습니다.' });
  res.json({ ok: true, card });
});

app.post('/api/send/email', async (req, res) => {
  try {
    const email = requireText(req.body.email, '이메일', 160);
    const cardId = requireText(req.body.cardId, '카드 ID', 100);
    const card = db.prepare(`SELECT id, sender, message FROM cards WHERE id = ?`).get(cardId);
    if (!card) return res.status(404).json({ ok: false, message: '카드를 찾을 수 없습니다.' });

    const url = `${BASE_URL}/card/${card.id}`;
    const subject = '💌 너에게 카드가 도착했어요';
    const html = `
      <div style="max-width:560px;margin:0 auto;padding:28px;font-family:Arial,'Noto Sans KR',sans-serif;background:#fff5fa;border:1px solid #f1a7c5;color:#55233b;line-height:1.7">
        <div style="font-size:12px;letter-spacing:2px;color:#a93d72;font-weight:700">YOU GOT A CARD</div>
        <h1 style="font-size:28px;margin:12px 0">💌 너에게 카드가 도착했어요</h1>
        <p><b>${escapeHtml(card.sender)}</b>님이 카드를 보냈어요.</p>
        <div style="padding:20px;border-radius:16px;background:#fff;border:2px solid #f0a0c0;white-space:pre-wrap">${escapeHtml(card.message).replaceAll('\n', '<br>')}</div>
        <p style="margin-top:22px">
          <a href="${url}" style="display:inline-block;padding:13px 20px;background:#c94f85;color:#fff;text-decoration:none;border-radius:10px;font-weight:700">카드 열기 💗</a>
        </p>
        <p style="font-size:12px;color:#8c4967">링크를 열고 YES / NO 버튼을 눌러주세요.</p>
      </div>
    `;

    const resend = getResend();
    if (resend) {
      const from = process.env.RESEND_FROM || 'onboarding@resend.dev';
      const { data, error } = await resend.emails.send({
        from,
        to: [email],
        subject,
        html
      });

      if (error) {
        console.error('Resend error:', error);
        return res.status(502).json({ ok: false, message: error.message || '이메일 발송에 실패했습니다.' });
      }

      return res.json({
        ok: true,
        provider: 'resend',
        emailId: data?.id || null,
        message: '이메일을 보냈습니다.',
        url
      });
    }

    const mailer = getTransporter();
    if (mailer) {
      await mailer.sendMail({
        from: process.env.SMTP_FROM || process.env.SMTP_USER,
        to: email,
        subject,
        text: `${card.sender}님이 카드를 보냈어요.\n\n${card.message}\n\n카드 열기: ${url}`,
        html
      });

      return res.json({ ok: true, provider: 'smtp', message: '이메일을 보냈습니다.', url });
    }

    return res.status(503).json({
      ok: false,
      message: '이메일 서비스 설정이 없습니다. RESEND_API_KEY를 설정해주세요.'
    });
  } catch (error) {
    console.error('Email endpoint error:', error);
    res.status(400).json({ ok: false, message: error.message });
  }
});

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

app.get('/card/:id', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'card.html'));
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Card Share Server: ${BASE_URL}`);
});
